# Google Forms Replica Backend

This is a backend server built with TypeScript and Express that replicates the functionality of Google Forms. It allows for form submissions to be saved and retrieved from a JSON file.

## Prerequisites

Before you begin, ensure you have met the following requirements:

- You have installed [Node.js](https://nodejs.org/) and npm.
- You have installed [TypeScript](https://www.typescriptlang.org/).

## Installation

To set up the project, follow these steps:

1. **Clone the Repository**:
    ```sh
    git clone https://github.com/your-username/your-repo-name.git
    cd your-repo-name
    ```

2. **Install Dependencies**:
    ```sh
    npm install
    ```

3. **Create the `tsconfig.json` File**:
    - In the root of your project directory, create a `tsconfig.json` file with the following content:
    ```json
    {
      "compilerOptions": {
        "target": "ES6",
        "module": "commonjs",
        "strict": true,
        "esModuleInterop": true,
        "outDir": "./dist",
        "rootDir": "./src"
      },
      "include": [
        "src/**/*.ts"
      ]
    }
    ```

4. **Create the Project Structure**:
    - In the project root, create a directory named `src`:
    ```sh
    mkdir src
    ```

5. **Create the `server.ts` and `db.json` Files**:
    - Inside the `src` directory, create a `server.ts` file:
    ```sh
    echo // TypeScript Server File > src/server.ts
    ```
    - Also, create an empty `db.json` file inside the `src` directory:
    ```sh
    echo [] > src/db.json
    ```

6. **Add Server Code to `server.ts`**:
    - Open `src/server.ts` and add the following code:
    ```typescript
    import express, { Request, Response } from 'express';
    import bodyParser from 'body-parser';
    import fs from 'fs';
    import path from 'path';

    const app = express();
    const PORT = 3000;
    const DB_FILE = path.join(__dirname, 'db.json');

    app.use(bodyParser.json());

    app.get('/ping', (req: Request, res: Response) => {
        res.send(true);
    });

    app.post('/submit', (req: Request, res: Response) => {
        const { name, email, phone, github_link, stopwatch_time } = req.body;

        const newSubmission = { name, email, phone, github_link, stopwatch_time };

        let data = [];
        if (fs.existsSync(DB_FILE)) {
            data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
        }

        data.push(newSubmission);
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));

        res.status(201).send('Submission saved');
    });

    app.get('/read', (req: Request, res: Response) => {
        const index = parseInt(req.query.index as string, 10);

        if (isNaN(index)) {
            return res.status(400).send('Invalid index');
        }

        if (fs.existsSync(DB_FILE)) {
            const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

            if (index >= 0 && index < data.length) {
                return res.json(data[index]);
            } else {
                return res.status(404).send('Submission not found');
            }
        } else {
            return res.status(404).send('No submissions found');
        }
    });

    app.listen(PORT, () => {
        console.log(`Server is running on http://localhost:${PORT}`);
    });
    ```

7. **Add Start Script to `package.json`**:
    - Open `package.json` and add the following script:
    ```json
    "scripts": {
      "start": "ts-node src/server.ts"
    }
    ```

## Running the Server

To start the server, run the following command:

```sh
npm start
