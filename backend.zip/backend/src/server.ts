// TypeScript Server File 
import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = 3000;
const DB_FILE = path.join(__dirname, 'db.json');

app.use(bodyParser.json());

app.get('/ping', (req: Request, res: Response) => {
    res.send(true);
});

app.post('/submit', (req: Request, res: Response) => {
    const { name, email, phone, github_link, stopwatch_time } = req.body;

    const newSubmission = { name, email, phone, github_link, stopwatch_time };

    let data = [];
    if (fs.existsSync(DB_FILE)) {
        data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    }

    data.push(newSubmission);
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));

    res.status(201).send('Submission saved');
});

app.get('/read', (req: Request, res: Response) => {
    const index = parseInt(req.query.index as string, 10);

    if (isNaN(index)) {
        return res.status(400).send('Invalid index');
    }

    if (fs.existsSync(DB_FILE)) {
        const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));

        if (index >= 0 && index < data.length) {
            return res.json(data[index]);
        } else {
            return res.status(404).send('Submission not found');
        }
    } else {
        return res.status(404).send('No submissions found');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
